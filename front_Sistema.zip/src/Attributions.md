Este arquivo do Figma Make inclui componentes de [shadcn/ui](https://ui.shadcn.com/) usados sob [licença MIT](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

Este arquivo do Figma Make inclui fotos do [Unsplash](https://unsplash.com) utilizadas sob [licença](https://unsplash.com/license).