import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { toast } from 'sonner@2.0.3';

interface FormularioAlunoProps {
  onBack: () => void;
  onSave: (data: any) => void;
  initialData?: any;
}

export default function FormularioAluno({ onBack, onSave, initialData }: FormularioAlunoProps) {
  const [formData, setFormData] = useState({
    nomeCompleto: '',
    cpf: '',
    curso: '',
    matricula: '',
    anoIngresso: '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData((prev) => ({
        ...prev,
        nomeCompleto: initialData.nomeCompleto || '',
        cpf: initialData.cpf || '',
      }));
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validações
    if (!formData.nomeCompleto || !formData.cpf || !formData.curso || !formData.matricula || !formData.anoIngresso) {
      toast.error('❌ Erro: Preencha todos os campos obrigatórios');
      return;
    }

    const anoAtual = new Date().getFullYear();
    const ano = parseInt(formData.anoIngresso);
    if (isNaN(ano) || ano < 1900 || ano > anoAtual + 1) {
      toast.error('❌ Erro: Ano de ingresso inválido');
      return;
    }

    // Salvar dados
    onSave({ ...formData, tipo: 'aluno' });
    toast.success('✅ Cadastro de Aluno realizado com sucesso!');
    
    // Limpar formulário
    setFormData({
      nomeCompleto: '',
      cpf: '',
      curso: '',
      matricula: '',
      anoIngresso: '',
    });

    // Voltar ao menu após 1 segundo
    setTimeout(() => {
      onBack();
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-3xl mx-auto">
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Menu
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Cadastro de Aluno</CardTitle>
            <CardDescription>
              {initialData 
                ? 'Complete os dados acadêmicos do aluno' 
                : 'Preencha os dados do aluno abaixo'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="nomeCompleto">
                    Nome Completo <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="nomeCompleto"
                    name="nomeCompleto"
                    value={formData.nomeCompleto}
                    onChange={handleChange}
                    placeholder="Digite o nome completo"
                    disabled={!!initialData}
                  />
                </div>

                <div>
                  <Label htmlFor="cpf">
                    CPF <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="cpf"
                    name="cpf"
                    value={formData.cpf}
                    onChange={handleChange}
                    placeholder="000.000.000-00"
                    disabled={!!initialData}
                  />
                </div>

                <div>
                  <Label htmlFor="matricula">
                    Matrícula <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="matricula"
                    name="matricula"
                    value={formData.matricula}
                    onChange={handleChange}
                    placeholder="Digite a matrícula"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="curso">
                    Curso <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="curso"
                    name="curso"
                    value={formData.curso}
                    onChange={handleChange}
                    placeholder="Digite o nome do curso"
                  />
                </div>

                <div>
                  <Label htmlFor="anoIngresso">
                    Ano de Ingresso <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="anoIngresso"
                    name="anoIngresso"
                    type="number"
                    value={formData.anoIngresso}
                    onChange={handleChange}
                    placeholder="2025"
                    min="1900"
                    max={new Date().getFullYear() + 1}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full">
                Salvar Cadastro
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
