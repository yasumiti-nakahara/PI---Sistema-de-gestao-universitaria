import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner@2.0.3';

interface FormularioProfessorProps {
  onBack: () => void;
  onSave: (data: any) => void;
  initialData?: any;
}

export default function FormularioProfessor({ onBack, onSave, initialData }: FormularioProfessorProps) {
  const [formData, setFormData] = useState({
    nomeCompleto: '',
    cpf: '',
    departamento: '',
    titulacao: '',
    dataContratacao: '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData((prev) => ({
        ...prev,
        nomeCompleto: initialData.nomeCompleto || '',
        cpf: initialData.cpf || '',
      }));
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, titulacao: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validações
    if (!formData.nomeCompleto || !formData.cpf || !formData.departamento || !formData.titulacao || !formData.dataContratacao) {
      toast.error('❌ Erro: Preencha todos os campos obrigatórios');
      return;
    }

    // Salvar dados
    onSave({ ...formData, tipo: 'professor' });
    toast.success('✅ Cadastro de Professor realizado com sucesso!');
    
    // Limpar formulário
    setFormData({
      nomeCompleto: '',
      cpf: '',
      departamento: '',
      titulacao: '',
      dataContratacao: '',
    });

    // Voltar ao menu após 1 segundo
    setTimeout(() => {
      onBack();
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-3xl mx-auto">
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Menu
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Cadastro de Professor</CardTitle>
            <CardDescription>
              {initialData 
                ? 'Complete os dados profissionais do professor' 
                : 'Preencha os dados do professor abaixo'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="nomeCompleto">
                    Nome Completo <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="nomeCompleto"
                    name="nomeCompleto"
                    value={formData.nomeCompleto}
                    onChange={handleChange}
                    placeholder="Digite o nome completo"
                    disabled={!!initialData}
                  />
                </div>

                <div>
                  <Label htmlFor="cpf">
                    CPF <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="cpf"
                    name="cpf"
                    value={formData.cpf}
                    onChange={handleChange}
                    placeholder="000.000.000-00"
                    disabled={!!initialData}
                  />
                </div>

                <div>
                  <Label htmlFor="departamento">
                    Departamento <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="departamento"
                    name="departamento"
                    value={formData.departamento}
                    onChange={handleChange}
                    placeholder="Digite o departamento"
                  />
                </div>

                <div>
                  <Label htmlFor="titulacao">
                    Titulação <span className="text-red-500">*</span>
                  </Label>
                  <Select value={formData.titulacao} onValueChange={handleSelectChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a titulação" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="graduacao">Graduação</SelectItem>
                      <SelectItem value="especializacao">Especialização</SelectItem>
                      <SelectItem value="mestrado">Mestrado</SelectItem>
                      <SelectItem value="doutorado">Doutorado</SelectItem>
                      <SelectItem value="pos-doutorado">Pós-Doutorado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="dataContratacao">
                    Data de Contratação <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="dataContratacao"
                    name="dataContratacao"
                    type="date"
                    value={formData.dataContratacao}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full">
                Salvar Cadastro
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
