import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner@2.0.3';

interface FormularioPessoaFisicaProps {
  onBack: () => void;
  onNavigate: (screen: string, data?: any) => void;
  onSave: (data: any) => void;
}

export default function FormularioPessoaFisica({ onBack, onNavigate, onSave }: FormularioPessoaFisicaProps) {
  const [showDialog, setShowDialog] = useState(false);
  const [savedData, setSavedData] = useState<any>(null);
  const [formData, setFormData] = useState({
    nomeCompleto: '',
    cpf: '',
    rg: '',
    dataNascimento: '',
    endereco: '',
    telefone: '',
    email: '',
  });

  const validarCPF = (cpf: string) => {
    cpf = cpf.replace(/[^\d]/g, '');
    if (cpf.length !== 11) return false;
    if (/^(\d)\1{10}$/.test(cpf)) return false;
    
    let soma = 0;
    for (let i = 0; i < 9; i++) {
      soma += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let resto = 11 - (soma % 11);
    let digito1 = resto >= 10 ? 0 : resto;
    
    if (digito1 !== parseInt(cpf.charAt(9))) return false;
    
    soma = 0;
    for (let i = 0; i < 10; i++) {
      soma += parseInt(cpf.charAt(i)) * (11 - i);
    }
    resto = 11 - (soma % 11);
    let digito2 = resto >= 10 ? 0 : resto;
    
    return digito2 === parseInt(cpf.charAt(10));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validações
    if (!formData.nomeCompleto || !formData.cpf || !formData.rg || !formData.dataNascimento) {
      toast.error('❌ Erro: Preencha todos os campos obrigatórios');
      return;
    }

    if (!validarCPF(formData.cpf)) {
      toast.error('❌ Erro: CPF inválido');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (formData.email && !emailRegex.test(formData.email)) {
      toast.error('❌ Erro: E-mail inválido');
      return;
    }

    // Salvar dados
    onSave({ ...formData, tipo: 'fisica' });
    setSavedData(formData);
    toast.success('✅ Cadastro de Pessoa Física realizado com sucesso!');
    setShowDialog(true);
  };

  const handleTornarAluno = () => {
    setShowDialog(false);
    onNavigate('aluno', savedData);
  };

  const handleTornarProfessor = () => {
    setShowDialog(false);
    onNavigate('professor', savedData);
  };

  const handleFinish = () => {
    setShowDialog(false);
    setFormData({
      nomeCompleto: '',
      cpf: '',
      rg: '',
      dataNascimento: '',
      endereco: '',
      telefone: '',
      email: '',
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-3xl mx-auto">
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Menu
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Cadastro de Pessoa Física</CardTitle>
            <CardDescription>Preencha os dados pessoais abaixo</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="nomeCompleto">
                    Nome Completo <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="nomeCompleto"
                    name="nomeCompleto"
                    value={formData.nomeCompleto}
                    onChange={handleChange}
                    placeholder="Digite o nome completo"
                  />
                </div>

                <div>
                  <Label htmlFor="cpf">
                    CPF <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="cpf"
                    name="cpf"
                    value={formData.cpf}
                    onChange={handleChange}
                    placeholder="000.000.000-00"
                    maxLength={14}
                  />
                </div>

                <div>
                  <Label htmlFor="rg">
                    RG <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="rg"
                    name="rg"
                    value={formData.rg}
                    onChange={handleChange}
                    placeholder="Digite o RG"
                  />
                </div>

                <div>
                  <Label htmlFor="dataNascimento">
                    Data de Nascimento <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="dataNascimento"
                    name="dataNascimento"
                    type="date"
                    value={formData.dataNascimento}
                    onChange={handleChange}
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="endereco">Endereço</Label>
                  <Input
                    id="endereco"
                    name="endereco"
                    value={formData.endereco}
                    onChange={handleChange}
                    placeholder="Digite o endereço completo"
                  />
                </div>

                <div>
                  <Label htmlFor="telefone">Telefone</Label>
                  <Input
                    id="telefone"
                    name="telefone"
                    value={formData.telefone}
                    onChange={handleChange}
                    placeholder="(00) 00000-0000"
                  />
                </div>

                <div>
                  <Label htmlFor="email">E-mail</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="email@exemplo.com"
                  />
                </div>
              </div>

              <Button type="submit" className="w-full">
                Salvar Cadastro
              </Button>
            </form>
          </CardContent>
        </Card>

        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Cadastro realizado com sucesso!</DialogTitle>
              <DialogDescription>
                Deseja vincular esta pessoa a um cadastro de Aluno ou Professor?
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="flex-col sm:flex-col gap-2">
              <Button onClick={handleTornarAluno} className="w-full">
                Tornar Aluno
              </Button>
              <Button onClick={handleTornarProfessor} variant="outline" className="w-full">
                Tornar Professor
              </Button>
              <Button onClick={handleFinish} variant="ghost" className="w-full">
                Finalizar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
