import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { toast } from 'sonner@2.0.3';

interface FormularioFornecedorProps {
  onBack: () => void;
  onSave: (data: any) => void;
  initialData?: any;
}

export default function FormularioFornecedor({ onBack, onSave, initialData }: FormularioFornecedorProps) {
  const [formData, setFormData] = useState({
    razaoSocial: '',
    cnpj: '',
    ramoAtividade: '',
    nomeResponsavel: '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData((prev) => ({
        ...prev,
        razaoSocial: initialData.razaoSocial || '',
        cnpj: initialData.cnpj || '',
      }));
    }
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validações
    if (!formData.razaoSocial || !formData.cnpj || !formData.ramoAtividade || !formData.nomeResponsavel) {
      toast.error('❌ Erro: Preencha todos os campos obrigatórios');
      return;
    }

    // Salvar dados
    onSave({ ...formData, tipo: 'fornecedor' });
    toast.success('✅ Cadastro de Fornecedor realizado com sucesso!');
    
    // Limpar formulário
    setFormData({
      razaoSocial: '',
      cnpj: '',
      ramoAtividade: '',
      nomeResponsavel: '',
    });

    // Voltar ao menu após 1 segundo
    setTimeout(() => {
      onBack();
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-3xl mx-auto">
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Menu
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Cadastro de Fornecedor</CardTitle>
            <CardDescription>
              {initialData 
                ? 'Complete os dados comerciais do fornecedor' 
                : 'Preencha os dados do fornecedor abaixo'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="razaoSocial">
                    Razão Social <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="razaoSocial"
                    name="razaoSocial"
                    value={formData.razaoSocial}
                    onChange={handleChange}
                    placeholder="Digite a razão social"
                    disabled={!!initialData}
                  />
                </div>

                <div>
                  <Label htmlFor="cnpj">
                    CNPJ <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="cnpj"
                    name="cnpj"
                    value={formData.cnpj}
                    onChange={handleChange}
                    placeholder="00.000.000/0000-00"
                    disabled={!!initialData}
                  />
                </div>

                <div>
                  <Label htmlFor="ramoAtividade">
                    Ramo de Atividade <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="ramoAtividade"
                    name="ramoAtividade"
                    value={formData.ramoAtividade}
                    onChange={handleChange}
                    placeholder="Digite o ramo de atividade"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="nomeResponsavel">
                    Nome do Responsável <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="nomeResponsavel"
                    name="nomeResponsavel"
                    value={formData.nomeResponsavel}
                    onChange={handleChange}
                    placeholder="Digite o nome do responsável"
                  />
                </div>
              </div>

              <Button type="submit" className="w-full">
                Salvar Cadastro
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
