import { Users, Building2, GraduationCap, UserCircle, Package } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

interface DashboardProps {
  onNavigate: (screen: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const menuItems = [
    {
      id: 'pessoa-fisica',
      title: 'Cadastrar Pessoa Física',
      description: 'CPF, RG e dados pessoais',
      icon: Users,
      color: 'bg-blue-500',
    },
    {
      id: 'pessoa-juridica',
      title: 'Cadastrar Pessoa Jurídica',
      description: 'CNPJ e dados da empresa',
      icon: Building2,
      color: 'bg-purple-500',
    },
    {
      id: 'aluno',
      title: 'Cadastrar Aluno',
      description: 'Matrícula e curso',
      icon: GraduationCap,
      color: 'bg-green-500',
    },
    {
      id: 'professor',
      title: 'Cadastrar Professor',
      description: 'Departamento e titulação',
      icon: UserCircle,
      color: 'bg-orange-500',
    },
    {
      id: 'fornecedor',
      title: 'Cadastrar Fornecedor',
      description: 'Ramo de atividade',
      icon: Package,
      color: 'bg-pink-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-slate-900 mb-2">Sistema de Gestão Universitária</h1>
          <p className="text-slate-600">
            Selecione o tipo de cadastro que deseja realizar
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Card
                key={item.id}
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => onNavigate(item.id)}
              >
                <CardHeader>
                  <div className={`w-12 h-12 ${item.color} rounded-lg flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle>{item.title}</CardTitle>
                  <CardDescription>{item.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full" variant="outline">
                    Acessar
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
