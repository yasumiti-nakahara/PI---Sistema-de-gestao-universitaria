import { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import Dashboard from './components/Dashboard';
import FormularioPessoaFisica from './components/FormularioPessoaFisica';
import FormularioPessoaJuridica from './components/FormularioPessoaJuridica';
import FormularioAluno from './components/FormularioAluno';
import FormularioProfessor from './components/FormularioProfessor';
import FormularioFornecedor from './components/FormularioFornecedor';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('dashboard');
  const [transitionData, setTransitionData] = useState<any>(null);
  const [cadastros, setCadastros] = useState<any[]>([]);

  const handleNavigate = (screen: string, data?: any) => {
    setCurrentScreen(screen);
    setTransitionData(data);
  };

  const handleSave = (data: any) => {
    setCadastros((prev) => [...prev, { ...data, id: Date.now() }]);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'pessoa-fisica':
        return (
          <FormularioPessoaFisica
            onBack={() => handleNavigate('dashboard')}
            onNavigate={handleNavigate}
            onSave={handleSave}
          />
        );
      case 'pessoa-juridica':
        return (
          <FormularioPessoaJuridica
            onBack={() => handleNavigate('dashboard')}
            onNavigate={handleNavigate}
            onSave={handleSave}
          />
        );
      case 'aluno':
        return (
          <FormularioAluno
            onBack={() => handleNavigate('dashboard')}
            onSave={handleSave}
            initialData={transitionData}
          />
        );
      case 'professor':
        return (
          <FormularioProfessor
            onBack={() => handleNavigate('dashboard')}
            onSave={handleSave}
            initialData={transitionData}
          />
        );
      case 'fornecedor':
        return (
          <FormularioFornecedor
            onBack={() => handleNavigate('dashboard')}
            onSave={handleSave}
            initialData={transitionData}
          />
        );
      default:
        return <Dashboard onNavigate={handleNavigate} />;
    }
  };

  return (
    <>
      {renderScreen()}
      <Toaster position="top-right" richColors />
    </>
  );
}
